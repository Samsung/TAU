var videoElement = {};
const TAG_SEPAPP = '[SEPAPP][main.js]';

window.onload = function () {

  let client;
  let meetingId;
  let session;

  client = new SEP.Client();

  client.on('connected', () => {
    console.log(`${TAG_SEPAPP} the client is connected to a server`);
  });

  client.on('disconnected', () => {
    console.log(`${TAG_SEPAPP} the client is disconnected from the server`);
  });

  client.connect().then(() => {
    console.log(`${TAG_SEPAPP} client.connect`);
  }).catch((error) => {
    console.error(`${TAG_SEPAPP} client.connect() error=: ${error}`);
  });

  document.getElementById('btn-createMeeting').addEventListener('click', () => {
    client.createMeeting().then(meetingId => {
      this.meetingId = meetingId;
      document.getElementById('meetingId').value = meetingId;
      console.log(`${TAG_SEPAPP} Meeting ${meetingId} is created`);
    }).catch((error) => {
      console.error(`${TAG_SEPAPP} client.createMeeting() error=: ${error}`);
    });
  });

  document.getElementById('btn-joinMeeting').addEventListener('click', () => {
    meetingId = document.getElementById('meetingId').value;
    console.log(`${TAG_SEPAPP} Join meeting Id : ${meetingId}`);
    if (meetingId === '') {
      alert("please input the meetingId");
      return;
    }
    session = client.createMeetingSession({ meetingId });

    session.setMediaView(createViewArea());

    session.on('connectionStateChanged', (data) => {
      console.log(`${TAG_SEPAPP} connectionStateChanged data.state=: ${data.state}`); // NONE, WAITING, JOINED, LEFT
    });

    session.join({
    }).then((data) => {
      // You've joined the meeting, check if you are waiting for the host to admit you to the meeting.
      console.log(`${TAG_SEPAPP} session join state : ${data.state}`);  // connection state: WAITING or JOINED

      session.getAllParticipants().then((data) => {
        data.forEach(target => {
          let remoteView;

          if (!videoElement[target.id]) {
            remoteView = createViewArea(target.id);
          }
          session.setParticipantMediaView(target.id, remoteView);
        });
      }).catch((error) => {
        console.error(`${TAG_SEPAPP} session getAllParticipants error : ${error}`);
      });
    }).catch((error) => {
      console.error(`${TAG_SEPAPP} session join error : ${error}`);
      // ERROR 1. Unable to connect to services
      // ERROR 2. Invalid password
      // ERROR 2. Invalid meeting ID
    });

    session.on('participantJoined', (data) => {
      console.log(`${TAG_SEPAPP} data.id : ${data.id}`);
      console.log(`${TAG_SEPAPP} data.displayName : ${data.displayName}`);
      console.log(`${TAG_SEPAPP} data.videoState : ${data.videoState}`);
      console.log(`${TAG_SEPAPP} data.audioState : ${data.audioState}`);

      let remoteView;

      if (!videoElement[data.id]) {
        remoteView = createViewArea(data.id);
      }
      session.setParticipantMediaView(data.id, remoteView);
    });
  });

  // for remote control
  let selectControl = document.getElementsByClassName('selectControl');

  document.getElementById('btn-createMeeting').focus();

  document.addEventListener('keydown', (event) => {
    let code = event.which ? event.which : event.keyCode;
    let order = 0;
    for (let i = 0; i < selectControl.length; i++)
      if (selectControl[i].id === document.activeElement.id) order = i;

    if (code === 38) { // Up Arrow Button
      if (order === 0) order = 6;
      selectControl[order - 1].focus();
    } else if (code === 40) { // Down Arrow Button
      if (order === 5) order = -1;
      selectControl[order + 1].focus();
    } else if (code === 13) { // Press Button
      if (document.activeElement.id === 'meetingId') {
        console.log(`${TAG_SEPAPP} meetingId function called.`);
      } else if (document.activeElement.id === 'btn-createMeeting') {
        console.log(`${TAG_SEPAPP} btn-createMeeting function called.`);
      } else if (document.activeElement.id === 'btn-joinMeeting') {
        console.log(`${TAG_SEPAPP} btn-joinMeeting function called.`);
      } else if (document.activeElement.id === 'btn-leaveMeeting') {
        console.log(`${TAG_SEPAPP} btn-leaveMeeting function called.`);
      } else if (document.activeElement.id === 'btn-videoOnOff') {
        console.log(`${TAG_SEPAPP} btn-videoOnOff function called.`);
      } else if (document.activeElement.id === 'btn-audioOnOff') {
        console.log(`${TAG_SEPAPP} btn-audioOnOff function called.`);
      }
    } else {
      console.log(`${TAG_SEPAPP} No Arrow keydown!`);
    }
  });
};

function createViewArea(id) {
  var mainArea = document.getElementById('mainArea');
  var videoContainer = document.createElement('div');
  var videoView = document.createElement('div');
  var infoData = document.createElement('div');
  var displayName = document.createElement('div');
  var videoState = document.createElement('div');
  var audioState = document.createElement('div');

  videoElement[id] = document.createElement('video');
  videoElement[id].autoplay = true;
  videoElement[id].style.objectFit = 'fill';
  videoElement[id].style.width = '571px';
  videoElement[id].style.height = '330px';
  if (id === undefined) {
    videoElement[id].id = 'local-video';
  } else {
    videoElement[id].id = id;
  }

  videoContainer.className = 'video-container';
  videoView.className = 'video-view';
  infoData.className = 'info-data';
  displayName.className = 'display-name';
  videoState.className = 'video-state';
  audioState.className = 'audio-state';

  displayName.innerText = 'Name : ';
  videoState.innerText = 'Video State : ';
  audioState.innerText = 'Audio State : ';

  videoView.appendChild(videoElement[id]);
  videoContainer.appendChild(videoView);
  infoData.appendChild(displayName);
  infoData.appendChild(videoState);
  infoData.appendChild(audioState);
  videoContainer.appendChild(infoData);
  mainArea.appendChild(videoContainer);

  return videoElement[id];
}
