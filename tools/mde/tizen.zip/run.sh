#!/bin/bash

tizen package -t wgt

tizen install -n ./SEPExample.wgt 

tizen run -p MAmRQjU1Hw.SEPExample
