# SEP Example for Tizen TV

This example shows how to use the SEP Client SDK to build applications for Tizen TV.

## Prerequisites

- You should manually update `js/sep.js` to the latest version of `sep.js`
- This application requires at least a [partner-signed certificate](https://developer.samsung.com/smarttv/develop/getting-started/setting-up-sdk/creating-certificates.html) to use camera and microphone in Tizen TV.

